getwd()
setwd("C:\\Users\\IT24102521\\Downloads\\Lab 05-20250829\\IT24102521")
getwd()

#01
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

Delivery_Times$Delivery_Time_.minutes. <- as.numeric(Delivery_Times$Delivery_Time_.minutes.)

hist(Delivery_Times$Delivery_Time_.minutes.,
     breaks = seq(20, 70, by = 5),
     right = TRUE,
     col = "lightblue",
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time",
     ylab = "Frequency")

#03
#The histogram shows a slightly right-skewed distribution,
#with a higher frequency of delivery times in the range of 30–50 minutes.
#There are fewer observations above 60 minutes.

cf <- cumsum(table(cut(Delivery_Times$Delivery_Time_.minutes., breaks = seq(20, 70, by = 5), right = TRUE)))

plot(seq(22.5, 67.5, by = 5), cf, type = "o", col = "blue",
     xlab = "Delivery Time", ylab = "Cumulative Frequency",
     main = "Cumulative Frequency Polygon (Ogive)")









data<-read.table("Data.txt",header=TRUE,sep=",")

fix(data)

attach(data)
name(data)<-c("X1","X2")
hist(X2,main = "Histogram for Number of Shareholders")
histograms<-hist(X2,main= "Histogram for Number of Shareholders",breaks=seq(130.270,length=8),right=FALSE
?hist               
breaks <-round(histogram$breaks)
freq <- histogram$counts
mids <-histograms$mids

Classes <- c()
for(iin 1:length(breaks)-1)
  classes[i]<- paste0("[,breaks[i+1],")")
cbind(Classes = classes,Frequency = freq)
